﻿using System;
using System.Windows.Forms;

namespace Question_3_ElisnaDeKock
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Begin with today's date and time now
            lblDateTime.Text = DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Ensure it's just a clean programming language name
            string language = txtLanguage.Text.Trim();

            // Prevent empty input
            if (string.IsNullOrWhiteSpace(language))
            {
                MessageBox.Show("Please enter a programming language.");
                return;
            }

            // Prevent duplicates
            if (lstLanguages.Items.Contains(language))
            {
                MessageBox.Show("This language is already in the list.");
                return;
            }

            // Add to list of listebox items
            lstLanguages.Items.Add(language);

            // Update date and time label
            lblDateTime.Text = "Last Added: " + language + " @ " + DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

            // Clear textbox
            txtLanguage.Clear();

            // Set focus to textbox
            txtLanguage.Focus();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            // Check if something is selected
            if (lstLanguages.SelectedItem != null)
            {
                lstLanguages.Items.Remove(lstLanguages.SelectedItem);
                // Update date and time
                lblDateTime.Text = "Last Removed: " + lstLanguages.SelectedItem + " @ " + DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

                // Set focus to textbox
                txtLanguage.Focus();
            }
            else
            {
                MessageBox.Show("Please select a language to remove from the list above.");
            }
        }
    }
}