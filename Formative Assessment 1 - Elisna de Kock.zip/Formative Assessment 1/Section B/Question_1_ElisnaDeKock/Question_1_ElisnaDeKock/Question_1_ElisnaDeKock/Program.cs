﻿using Question_1_ElisnaDeKock;

class Program
{
    static void Main()
    {
        // Display welcome message
        Console.WriteLine("=== Welcome to Emfuleni Municipality Service Desk ===");

        // ===== RESIDENT DATA CAPTURE =====
        Console.Write("How many residents do you want to register? ");
        int residentCount = int.Parse(Console.ReadLine()); // Number of residents to capture

        // Create a list to store Resident objects
        List<Resident> residents = new List<Resident>();

        // Loop to capture each resident's details
        for (int i = 0; i < residentCount; i++)
        {
            Console.WriteLine($"\n--- Resident {i + 1} ---");

            Console.Write("Name: ");
            string name = Console.ReadLine();

            Console.Write("Address: ");
            string address = Console.ReadLine();

            Console.Write("Account Number: ");
            string account = Console.ReadLine();

            Console.Write("Monthly Utility Usage: ");
            double usage = double.Parse(Console.ReadLine());

            // Create a Resident object and add it to the list
            residents.Add(new Resident(name, address, account, usage));
        }

        // ===== SERVICE REQUEST CAPTURE =====
        Console.Write("\nHow many service requests do you want to log? ");
        int requestCount = int.Parse(Console.ReadLine()); // Number of service requests

        // List to store all service requests
        List<ServiceRequest> requests = new List<ServiceRequest>();

        // Loop to capture each service request
        for (int i = 0; i < requestCount; i++)
        {
            Console.WriteLine($"\n--- Service Request {i + 1} ---");

            // Select which resident this request belongs to
            Console.Write($"Select resident number (1 to {residentCount}): ");
            int residentIndex = int.Parse(Console.ReadLine()) - 1; // Adjust for zero-based index

            Console.Write("Request Type: ");
            string type = Console.ReadLine();

            Console.Write("Priority Level (1-5): ");
            int priority = int.Parse(Console.ReadLine());

            Console.Write("Severity Level (1-10): ");
            int severity = int.Parse(Console.ReadLine());

            Console.Write("Estimated Resolution Hours: ");
            int hours = int.Parse(Console.ReadLine());

            // Create ServiceRequest object and add to list
            requests.Add(new ServiceRequest(residentIndex, type, priority, severity, hours));
        }

        // ===== PROCESSING REQUESTS =====
        int highestScore = 0;                 // Track highest urgency score
        ServiceRequest highestRequest = null; // Store request with highest urgency

        // Loop through each request
        foreach (var req in requests)
        {
            // Calculate urgency and adjusted resolution using UtilitiesManager
            int urgency = UtilitiesManager.CalculateUrgency(req);
            int adjusted = UtilitiesManager.AdjustResolution(req);

            // Get the corresponding resident for this request
            Resident res = residents[req.ResidentIndex];

            // Display service report for current request
            Console.WriteLine("\n==== Service Report ====");
            Console.WriteLine("Resident: " + res.Name);
            Console.WriteLine("Service Type: " + req.RequestType);
            Console.WriteLine("Urgency Score: " + urgency);
            Console.WriteLine("Adjusted Resolution: " + adjusted + " hours");

            // Household impact = urgency * monthly usage
            Console.WriteLine("Household Impact Score: " + (urgency * res.MonthlyUsage));

            // Check if this is the highest urgency so far
            if (urgency > highestScore)
            {
                highestScore = urgency;
                highestRequest = req;
            }
        }

        // ===== FINAL SUMMARY =====
        if (highestRequest != null)
        {
            // Get resident linked to highest urgency request
            Resident res = residents[highestRequest.ResidentIndex];

            Console.WriteLine("\n==== FINAL MUNICIPAL SUMMARY ====");
            Console.WriteLine("Highest priority issue:");
            Console.WriteLine("Resident: " + res.Name);
            Console.WriteLine("Service Type: " + highestRequest.RequestType);
            Console.WriteLine("Urgency Score: " + highestScore);
        }

        // Closing message
        Console.WriteLine("\nThank you for using the Emfuleni Municipality Service Desk.");
        Console.ReadKey(); // Pause before closing
    }
}