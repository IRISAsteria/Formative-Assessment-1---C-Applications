﻿namespace Question_1_ElisnaDeKock
{
    // The UtilitiesManager class handles processing logic for service requests
    internal class UtilitiesManager
    {
        // Calculates the urgency score of a service request
        // Urgency is determined by multiplying priority and severity levels
        public static int CalculateUrgency(ServiceRequest request)
        {
            return request.PriorityLevel * request.SeverityLevel;
        }

        // Adjusts the estimated resolution time based on severity
        // Higher severity increases the total resolution time
        public static int AdjustResolution(ServiceRequest request)
        {
            return request.EstimatedHours + (request.SeverityLevel / 2);
        }
    }
}