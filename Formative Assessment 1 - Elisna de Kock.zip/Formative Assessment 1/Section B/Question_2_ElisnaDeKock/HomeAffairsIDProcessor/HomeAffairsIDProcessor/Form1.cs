﻿using System;
using System.Windows.Forms;

namespace HomeAffairsIDProcessor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            // Remove leading and trailing whitespace - clean user input.
            string name = txtUserName.Text.Trim();
            string id = txtUserID.Text.Trim();
            string status = cmbCitizen.SelectedItem?.ToString();

            // The textboxes cannot be left empty
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(id) || status == null)
            {
                MessageBox.Show("Please complete all fields.");
                return;
            }

            // Creates a new profil object for the user's details that are entered.
            CitizenProfile profile = new CitizenProfile(name, id, status);

            // Displays whether ID is valid or not.
            string result = profile.ValidateID();
            lblResult.Text = result;
        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
            string name = txtUserName.Text.Trim();
            string id = txtUserID.Text.Trim();
            string status = cmbCitizen.SelectedItem?.ToString();

            // Ensures the input is not empty
            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(id) || status == null)
            {
                MessageBox.Show("Please complete all fields.");
                return;
            }

            // Creates a new citizen profile
            CitizenProfile profile = new CitizenProfile(name, id, status);
            string validation = profile.ValidateID();

            // Format of information of user profile for rich text box to be displayed in.
            string output =
                "==== DIGITAL CITIZEN SUMMARY ====\r\n" +
                $"Name: {profile.FullName}\r\n" +
                $"ID Number: {profile.IDNumber}\r\n" +
                $"Age: {profile.Age}\r\n" +
                $"Citizenship: {profile.CitizenshipStatus}\r\n" +
                $"Validation: {validation}\r\n" +
                $"Processed at: Home Affairs Digital Desk\r\n" +
                $"Timestamp: {DateTime.Now:yyyy/MM/dd HH:mm:ss}";

            // Sets text of rtb to the formatted profile.
            rtbProfile.Text = output;
        }
    }
}
