﻿namespace Question_1_ElisnaDeKock
{
    // The ServiceRequest class represents a utility/service issue reported by a resident
    internal class ServiceRequest
    {
        // Index used to link this request to a specific resident in the residents list
        public int ResidentIndex { get; set; }

        // Type of service request (e.g., Water Outage, Burst Pipe)
        public string RequestType { get; set; }

        // Priority level of the request (1–5, where higher means more important)
        public int PriorityLevel { get; set; }

        // Severity level of the issue (1–10, where higher means more severe)
        public int SeverityLevel { get; set; }

        // Estimated number of hours required to resolve the issue
        public int EstimatedHours { get; set; }

        // Constructor used to initialise a ServiceRequest object with provided values
        public ServiceRequest(int residentIndex, string type, int priority, int severity, int hours)
        {
            ResidentIndex = residentIndex;   // Link to resident
            RequestType = type;              // Assign request type
            PriorityLevel = priority;        // Assign priority level
            SeverityLevel = severity;        // Assign severity level
            EstimatedHours = hours;          // Assign estimated resolution time
        }
    }
}