﻿using System;

class Program
{
    static void Main()
    {
        /// Student name validation - string is a non-nullable value
        string name;

        while (true)
        {
            Console.Write("Enter student name: ");
            name = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(name))
            {
                break;
            }
            else
            {
                Console.WriteLine("Name cannot be empty. Please try again.");
            }
        }
        // Collect student's marks + Validate
        double mark1 = GetValidMark("Enter mark for subject 1: ");
        double mark2 = GetValidMark("Enter mark for subject 2: ");
        double mark3 = GetValidMark("Enter mark for subject 3: ");

        // Calculate average
        double total = mark1 + mark2 + mark3;
        double average = total / 3;

        // The student only pass if ave score is 50 and above.
        string result = average >= 50 ? "PASS" : "FAIL";

        // Output
        Console.WriteLine("\n--- Student Results ---");
        Console.WriteLine("Name: " + name);
        Console.WriteLine("Total Marks: " + total);
        Console.WriteLine("Average: " + average);
        Console.WriteLine("Result: " + result);

        Console.WriteLine("\nPress any key to exit...\n");
        Console.ReadKey();
    }


    // Function for validating input
    static double GetValidMark(string message)
    {
        double mark;
        // Keeps asking until a number is entered.
        while (true)
        {
            Console.Write(message);
            string input = Console.ReadLine();

            if (double.TryParse(input, out mark))
            {
                // If mark is numeric value
                return mark;
            }
            else
            {
                // Prompt user to try again if value is incorrect.
                Console.WriteLine("Invalid input. Please enter a numeric value.");
            }
        }
    }
}