﻿namespace Question_1_ElisnaDeKock
{
    // The Resident class stores information about a municipal resident
    internal class Resident
    {
        // Properties to hold resident details
        public string Name { get; set; }              // Resident's full name
        public string Address { get; set; }           // Residential address
        public string AccountNumber { get; set; }     // Unique account number
        public double MonthlyUsage { get; set; }      // Monthly utility usage (e.g., water/electricity)

        // Constructor used to initialise a Resident object with provided values
        public Resident(string name, string address, string accountNumber, double usage)
        {
            Name = name;                    // Assign name
            Address = address;              // Assign address
            AccountNumber = accountNumber;  // Assign account number
            MonthlyUsage = usage;           // Assign monthly usage
        }
    }
}