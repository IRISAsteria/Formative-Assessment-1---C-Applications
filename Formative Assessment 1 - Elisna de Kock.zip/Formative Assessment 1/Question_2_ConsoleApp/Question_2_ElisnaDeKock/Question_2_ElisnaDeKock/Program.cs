﻿using System;

class Program
{
    static void Main()
    {
        // ATM App Title
        Console.WriteLine("===== CTU SIMPLE ATM SYSTEM =====\n");

        // Name validation constantly until valid value is entered.
        string name;
        while (true)
        {
            Console.Write("HI, WHAT IS YOUR NAME? ");
            name = Console.ReadLine();

            if (!string.IsNullOrWhiteSpace(name))
                break;
            else
                Console.WriteLine("Name cannot be empty. Please try again.");
        }

        Console.WriteLine("\nWELCOME " + name.ToUpper() + "!");

        // Prompt user to enter their balance amount.
        double balance = GetValidAmount("Enter account balance: ");

        // Prompt user to enter amount of withdrawal
        double withdrawal = GetValidAmount("Enter withdrawal amount: ");

        if (withdrawal <= balance)
        {
            // If the withdrawal amount does not exceed balance, user can withdraw.
            balance -= withdrawal;

            Console.WriteLine("\n=== Withdrawal successful! ===");
            // Balance is a float data type and will be rounded off to 2 decimal places.
            Console.WriteLine("Updated Balance: " + balance.ToString("F2"));
        }
        else
        {
            // Else, the app will inform user they do not have enough funds.
            Console.WriteLine("\n=== Transaction failed: Insufficient funds. ===");
        }

        // Date and time formatting
        Console.WriteLine("Transaction Time: " + DateTime.Now.ToString("dd MMM yyyy HH:mm:ss"));

        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }

    // Validation method
    static double GetValidAmount(string message)
    {
        double amount;

        // Ensures constant user input
        while (true)
        {
            Console.Write(message);
            string input = Console.ReadLine();

            if (double.TryParse(input, out amount) && amount >= 0)
            {
                return amount;
            }
            else
            {
                Console.WriteLine("Invalid input. Enter a positive numeric value.");
            }
        }
    }
}