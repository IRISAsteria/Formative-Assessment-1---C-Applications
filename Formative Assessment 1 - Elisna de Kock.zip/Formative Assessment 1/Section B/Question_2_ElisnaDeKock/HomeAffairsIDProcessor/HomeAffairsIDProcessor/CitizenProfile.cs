﻿using System;

namespace HomeAffairsIDProcessor
{
    internal class CitizenProfile
    {
        // Attributes of class CitizenProfile
        public string FullName { get; set; }
        public string IDNumber { get; set; }
        public int Age { get; set; }
        public string CitizenshipStatus { get; set; }

        // Constructor for class
        public CitizenProfile(string name, string id, string status)
        {
            FullName = name;
            IDNumber = id;
            CitizenshipStatus = status;
            Age = CalculateAge();
        }

        // Method to calculate the user's age from their ID number
        private int CalculateAge()
        {
            try
            {
                // Extract the birthdate
                string yy = IDNumber.Substring(0, 2);
                string mm = IDNumber.Substring(2, 2);
                string dd = IDNumber.Substring(4, 2);

                // Assign to appropriate variables
                int year = int.Parse(yy);
                int month = int.Parse(mm);
                int day = int.Parse(dd);

                // Determine century
                int fullYear = (year > DateTime.Now.Year % 100) ? 1900 + year : 2000 + year;


                DateTime birthDate = new DateTime(fullYear, month, day);

                int age = DateTime.Now.Year - birthDate.Year;

                if (DateTime.Now < birthDate.AddYears(age))
                    age--;

                return age;
            }
            catch
            {
                return 0;
            }
        }

        // Method to check whether ID is:
        public string ValidateID()
        {
            // Entered properly - not left as nothing
            if (string.IsNullOrWhiteSpace(IDNumber))
                return "ID cannot be empty.";

            // 13 digits long
            if (IDNumber.Length != 13)
                return "ID must be 13 digits.";

            // Made up of numeric characters
            if (!long.TryParse(IDNumber, out _))
                return "ID must be numeric.";

            // If something fails then user will be informed via the label.
            if (Age <= 0)
                return "Invalid ID: Could not determine age.";

            // If successful and ID is valid, return age of user.
            return $"Valid ID. Citizen is {Age} years old.";
        }
    }
}
